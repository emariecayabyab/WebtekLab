/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.underscore;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author s326lab
 */
@WebServlet(name = "Post", urlPatterns = {"/Post"})
public class Post extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter pw = response.getWriter();
        String content = request.getParameter("content");
        String idno = request.getParameter("idno");
        String privacy = request.getParameter("privacy");
        
        InputStream inputStream = null;

        Part filePart = request.getPart("fileToUpload");
        if (filePart != null) {
            System.out.println(filePart.getName());
            System.out.println(filePart.getSize());
            System.out.println(filePart.getContentType());

            inputStream = filePart.getInputStream();
            
        }
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/underscore", "root", "");
            PreparedStatement ps = conn.prepareStatement("INSERT INTO posts (idno, content, privacy, date, file) VALUES (?, ?, ?, now(), ?)");
            
            ps.setString(1, idno);
            ps.setString(2, content);
            ps.setString(3, privacy);

            if (inputStream != null) {
                ps.setBlob(4, inputStream);
            }
            
            int rs = ps.executeUpdate();
            pw.println("here");

            if(rs > 0){
                response.sendRedirect("dashboard2.jsp");
            } else {
                response.sendRedirect("dashboard2.jsp");
            }
        } catch (Exception e) {
            
        }
    }
}
