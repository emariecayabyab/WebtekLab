<?php include('database.php'); ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>
      Admin Dashboard
    </title>
    <link rel="stylesheet" href="bootstrap-3.3.7-dist\css\bootstrap.min.css">
  </head>
  <body>
    <?php include('navbar.php');
      $idno = $_POST['idno'];

      $sql = "SELECT * FROM friends JOIN users ON users.idno=friends.f1 WHERE f2=$idno";
      $result = mysqli_query($conn, $sql);
      $rows = mysqli_fetch_array($result, MYSQLI_ASSOC);
    ?>

    <div class="container-fluid" align="center">
      Friends of <strong><?php echo $idno ?></strong>
    </div>
    <table class="table table-hover">
      <thead>
        <th>User ID</th>
        <th>Name</th>
        <th>Friend Since</th>
      </thead>

      <?php do{
        ?>
          <tr>
            <td><?php echo $rows['f1'] ?></td>
            <td><?php echo $rows['firstname'] . " " . $rows['lastname'] ?></td>
            <td><?php echo $rows['since'] ?></td>
          </tr>
        <?php
      } while($rows = mysqli_fetch_assoc($result));
      ?>
    </table>
  </body>
</html>
