<?php
  session_start();
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbasename = "underscore";

  $conn = new mysqli($servername, $username, $password, $dbasename);

?>
