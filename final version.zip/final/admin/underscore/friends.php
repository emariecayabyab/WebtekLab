<?php
  include('database.php');
 ?>
 <!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>
    Admin Dashboard
  </title>
  <link rel="stylesheet" href="bootstrap-3.3.7-dist\css\bootstrap.min.css">
</head>
  <body>
    <?php include('navbar.php'); ?>

    <table class="table table-hover">
      <thead>
        <th>User ID</th>
        <th>Name</th>
        <th>Friends</th>
        <th>Action</th>
      </thead>
      <?php
      $sql = "SELECT * FROM users ORDER BY idno";
      $result = mysqli_query($conn, $sql);
      $rows = mysqli_fetch_array($result, MYSQLI_ASSOC);

        do{
          ?>
          <tr>
           <td><?php echo $rows['idno'] ?></td>
           <td><?php echo $rows['firstname'] . " " . $rows['lastname'] ?></td>
           <td><?php $count_friends = "SELECT * FROM friends WHERE f2=$rows[idno]";
                $count = mysqli_query($conn, $count_friends);
                $friends = mysqli_num_rows($count);
                echo $friends;
            ?></td>
           <?php if(strcasecmp($rows['userType'], "admin")==0){
             ?> <td>Admin</td>
             <?php
           } else {
             ?>
             <form action="viewFriends.php" method="POST">
               <input type="hidden" name="idno" value="<?php echo $rows['idno'] ?>">
               <td><button type="submit" name="button" class="btn btn-primary">View Friends</button></td>
             </form>
           <?php
         } ?>
         </tr>
          <?php
        }while ($rows = mysqli_fetch_assoc($result));
       ?>
    </table>
  </body>
</html>
